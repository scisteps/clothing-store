
export interface SectionTitleProps {

}