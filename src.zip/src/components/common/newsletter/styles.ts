import { styled, keyframes } from 'stitches.config'
import * as Dialog from '@radix-ui/react-dialog';

export const Container = styled('div', {})

export const {
  Root,
  Trigger,
  Close,
  Portal
} = Dialog

const overlayShow = keyframes({
  '0%': { opacity: 0 },
  '100%': { opacity: 1 },
});

const contentShow = keyframes({
  '0%': { opacity: 0, transform: 'translate(-50%, -48%) scale(.96)' },
  '100%': { opacity: 1, transform: 'translate(-50%, -50%) scale(1)' },
});

export const Overlay = styled(Dialog.Overlay, {
  backgroundColor: 'transparent',
  position: 'fixed',
  inset: 0,
  animation: `${overlayShow} 150ms cubic-bezier(0.16, 1, 0.3, 1)`,
  backdropFilter: 'blur(6px)',
  zIndex: 88,
});


export const Content = styled(Dialog.Content, {
  backgroundColor: '$foreground',
  borderRadius: '8px',
  boxShadow: '0 10px 30px rgba(0, 0, 0, .12)',
  position: 'fixed',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '90vw',
  maxWidth: '750px',
  maxHeight: '85vh',
  animation: `${contentShow} 150ms cubic-bezier(0.16, 1, 0.3, 1)`,
  '&:focus': { outline: 'none' },
  overflow: 'hidden',
  display: 'flex',
  zIndex: 88,
});

export const Figure = styled('figure', {
  width: '400px',
  position: 'relative',
  height: '400px',
  img: {
    objectFit: 'cover'
  }
})

export const FormView = styled('div', {
  padding: '1rem',
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  gap: '1rem'
})

export const Form = styled('form', {
  display: 'flex',
  flexDirection: 'column',
  gap: '1rem'
})

export const ButtonIconView = styled('div', {
  position: 'absolute',
  top: '20px',
  right: '20px'
})